import os

os.open('hello.png')